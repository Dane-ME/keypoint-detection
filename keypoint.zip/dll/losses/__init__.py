from .keypoint_loss import KeypointLoss, ImprovedKeypointLoss

__all__ = ['KeypointLoss', 'ImprovedKeypointLoss']